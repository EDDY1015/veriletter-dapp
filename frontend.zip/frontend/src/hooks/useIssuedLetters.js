import { useEffect, useState } from "react";
import { JsonRpcProvider } from "ethers";
import { Contract } from "ethers";
import OFFER_VERIFIER_ABI from "../utils/VeriLetterABI.json";
import { getIssuerIdFromEmail } from "../utils/issuerUtils";

const CONTRACT_ADDRESS = process.env.REACT_APP_PROXY_ADDRESS;
const RPC_URL = process.env.REACT_APP_RPC_URL;

export default function useIssuedLetters(email) {
  const [letters, setLetters] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!email) return;

    const fetchEvents = async () => {
      setLoading(true);
      try {
        const provider = new JsonRpcProvider(RPC_URL);
        const contract = new Contract(CONTRACT_ADDRESS, OFFER_VERIFIER_ABI, provider);
      

        const issuerId = getIssuerIdFromEmail(email);
        const filter = contract.filters.OfferLetterIssued(null, null, issuerId);

        const events = await contract.queryFilter(filter, 0, "latest");

        const parsed = events.map((e) => ({
          fileHash: e.args.fileHash,
          issuerWallet: e.args.issuerWallet,
          issuerId: e.args.issuerId,
          subjectIdHash: e.args.subjectIdHash,
          issueDate: new Date(e.args.issueDate.toNumber() * 1000),
          expiryDate: new Date(e.args.expiryDate.toNumber() * 1000),
          txHash: e.transactionHash
        }));

        setLetters(parsed);
      } catch (err) {
        console.error("Error fetching letters:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, [email]);

  return { letters, loading };
}
